To compile 
 ./compileall.sh 
 If it show permission denied => chmod u+x compileall.sh plaintext1 plaintext2 plaintext3 plaintext4 plaintext5
 Then
 ./p5testscript RANDOM_PORT1 RANDOM_PORT2 > Result > 2&1

 RANDOM_PORT1 and RANDOM_PORT2 need to be replaced with value that is 50000+ 